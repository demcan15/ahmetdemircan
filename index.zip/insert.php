<?php
$username = $_POST['username'];
$password = $_POST['password'];
$gender = $_POST['gender'];
$email = $_POST['email'];
$phoneCode = intval($_POST['phoneCode']);
$phone = intval($_POST['phone']);

if (!empty($username) && !empty($password) && !empty($gender) && !empty($email) && !empty($phoneCode) && !empty($phone)) {

    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "user";

    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

    if ($conn->connect_error) {
        die("❌ Connection error: " . $conn->connect_error);
    }

    $SELECT = "SELECT email FROM users WHERE email = ? LIMIT 1";
    $stmt = $conn->prepare($SELECT);

    if ($stmt === false) {
        die("❌ Failed to prepare query (SELECT):" . $conn->error);
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows == 0) {
        $stmt->close();

        $plain_password = $password;

        $INSERT = "INSERT INTO users (username, password, gender, email, phoneCode, phone) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($INSERT);

        if ($stmt === false) {
            die("❌ Failed to prepare query (SELECT): " . $conn->error);
        }

        $stmt->bind_param("ssssii", $username, $plain_password, $gender, $email, $phoneCode, $phone);

        if ($stmt->execute()) {
            echo "✅ New user added successfully.";
        } else {
            echo "❌ An error occurred during registration:" . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "⚠️ This email address has already been registered.";
        $stmt->close();
    }

    $conn->close();

} else {
    echo "❗ Please fill in all fields.";
}
?>





